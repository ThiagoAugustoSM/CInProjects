import string
import random
alphabet = string.ascii_uppercase

arquivos = int(input("Quantidade de arquivos: "))
linhas = int(input("Quantidade de linhas: "))
mincasos = int(input("Quantidade minima de casos por arquivo: "))
maxcasos = int(input("Quantidade maxima de casos por arquivo: "))

file_names = open ("cidades", "r")
names = file_names.read().splitlines()

for i in range(arquivos):
    file = open("case" + str(i), "w")
    for j in range(random.randint(mincasos, maxcasos)):
        code = random.sample(alphabet, 3)
        code.append(str(random.randint(100, 999)))
        code2 = ''.join(code)
        name = random.choice(names)
        hora = str(random.randint(0, 23)).zfill(2) + ":" + str(random.randint(0, 59)).zfill(2)
        file.write(str(random.randint(1, linhas)) + "\n")    
        file.write(code2 + " " + name + " " + hora + "\n")

file.close()